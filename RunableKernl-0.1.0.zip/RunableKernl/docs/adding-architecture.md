# Adding a New Architecture to RunableKernl

RunableKernl is designed to be highly portable. To add a new architecture (e.g., `arm64`):

1. **Create Directory**: `mkdir arch/arm64/`
2. **Boot Code**: Add `boot.S`. This is the entry point. Setup the stack and call `kmain()`.
3. **HAL Implementation**:
   - Create `arch.h` and `arch.c`
   - Implement `arch_init()`
   - Implement `arch_putchar(char c)` for serial console
   - Implement `arch_halt()` to safely loop/stop the CPU
4. **Linker Script**: Add `linker/arm64.ld` to place the kernel at the correct physical/virtual address.
5. **Makefile**: Update `Makefile` to recognize `ARCH=arm64` and set the appropriate cross-compiler (e.g., `aarch64-linux-gnu-gcc`).
