#ifndef CONSOLE_H
#define CONSOLE_H

void console_init(void);
void console_putchar(char c);
void console_puts(const char* str);

#endif // CONSOLE_H
