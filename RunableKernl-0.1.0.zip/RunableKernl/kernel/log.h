#ifndef LOG_H
#define LOG_H

void log_info(const char* msg);
void log_ok(const char* msg);
void log_fail(const char* msg);
void log_skip(const char* msg);
void kernel_panic(const char* reason);

#endif // LOG_H
