#include "interrupts.h"
#include "log.h"

void interrupts_init(void) {
    // Foundation for interrupt handling
    log_ok("Interrupt foundation");
}

void timer_init(void) {
    // Foundation for timer interrupts
    log_ok("Timer foundation");
}
