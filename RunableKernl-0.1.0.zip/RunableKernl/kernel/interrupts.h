#ifndef INTERRUPTS_H
#define INTERRUPTS_H

void interrupts_init(void);
void timer_init(void);

#endif // INTERRUPTS_H
