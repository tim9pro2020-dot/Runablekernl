#include "log.h"
#include "console.h"
#include "../arch/riscv64/arch.h"

void log_info(const char* msg) {
    console_puts("[INFO] ");
    console_puts(msg);
    console_puts("\n");
}

void log_ok(const char* msg) {
    console_puts("[ OK ] ");
    console_puts(msg);
    console_puts("\n");
}

void log_fail(const char* msg) {
    console_puts("[FAIL] ");
    console_puts(msg);
    console_puts("\n");
}

void log_skip(const char* msg) {
    console_puts("[ -- ] ");
    console_puts(msg);
    console_puts("\n");
}

void kernel_panic(const char* reason) {
    console_puts("\n[KERNEL PANIC]\nReason: ");
    console_puts(reason);
    console_puts("\nSystem halted.\n");
    arch_halt();
}
