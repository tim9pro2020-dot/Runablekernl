#include "memory.h"
#include "log.h"

void memory_init(void) {
    // Foundation for physical memory manager
    log_ok("Memory foundation");
}
