#include "console.h"
#include "log.h"
#include "memory.h"
#include "interrupts.h"
#include "../arch/riscv64/arch.h"

void kmain(void) {
    // 1. Architecture specific low-level init
    arch_init();
    
    // 2. Common console init
    console_init();

    // 3. Boot sequence
    console_puts("\nRunableKernl booting...\n");
    log_ok("Boot entry");
    log_ok("Architecture detection");
    log_ok("Architecture: RISC-V RV64");
    
    // Init subsystems
    memory_init();
    interrupts_init();
    timer_init();
    
    log_ok("UART");
    log_ok("Console");
    log_ok("Logger");
    log_ok("Kernel initialization");
    
    // Components status
    log_skip("Framebuffer component not present");
    log_skip("Filesystem not implemented");
    
    log_ok("System ready");

    // ASCII Art
    console_puts("\n");
    console_puts(" ____                   _     _     _      _  ___ \n");
    console_puts("|  _ \\ _   _ _ __   ___| |__ | |   / \\    | |/ / |\n");
    console_puts("| |_) | | | | '_ \\ / _ \\ '_ \\| |  / _ \\   | ' /| |\n");
    console_puts("|  _ <| |_| | | | |  __/ |_) | | / ___ \\  | . \\| |\n");
    console_puts("|_| \\_\\\\__,_|_| |_|\\___|_.__/|_|/_/   \\_\\ |_|\\_\\_|\n");
    console_puts("        SYSTEM INITIALIZED\n\n");
    console_puts("RunableKernl 0.1.0 (Experimental)\n");

    // Halt CPU (idle loop)
    arch_halt();
}
