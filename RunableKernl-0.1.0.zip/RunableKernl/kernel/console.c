#include "console.h"
#include "../arch/riscv64/arch.h" // TODO: make it arch-independent via build system include path

void console_init(void) {
    // Console initialization relies on arch_init being called first
}

void console_putchar(char c) {
    arch_putchar(c);
}

void console_puts(const char* str) {
    while (*str) {
        console_putchar(*str++);
    }
}
