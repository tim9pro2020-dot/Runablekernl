# Component System

RunableKernl uses a modular approach. The core kernel remains small, and additional functionalities are implemented as optional components.

## Planned Components
- `uart/` (currently tightly coupled in arch for boot, will be moved here)
- `framebuffer/`
- `vga/`
- `usb/`
- `network/`
- `filesystem/`

Components should provide an `init()`, `probe()`, and `register()` interface to interact with the common C kernel without bloating it.
