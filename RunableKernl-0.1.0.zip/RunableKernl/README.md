# RunableKernl 0.1.0

RunableKernl is an experimental, minimalistic operating system kernel focused on extreme portability.

## Core Philosophy
- **SMALL**: Minimal kernel footprint.
- **PORTABLE**: Designed to run on various CPU architectures.
- **MODULAR**: Optional features are kept as components.
- **LOW-LEVEL**: Written in C and Assembly.
- **NO UNNECESSARY DEPENDENCIES**: No libc, no Rust, no Linux overhead.

## Current Status
- Architecture: RISC-V 64-bit (RV64)
- Platform: QEMU `virt` machine
- Features: Assembly boot, C kernel entry, minimal HAL, 16550A UART console, detailed boot logging.

## Prerequisites
To build and run RunableKernl, you need a RISC-V toolchain and QEMU:
- `riscv64-unknown-elf-gcc`
- `qemu-system-riscv64`

*(On Ubuntu/Debian: `sudo apt install gcc-riscv64-unknown-elf qemu-system-misc`)*

## Build & Run
To build the kernel:
```bash
make
```

To run in QEMU:
```bash
make run
```
This executes `qemu-system-riscv64 -machine virt -nographic -bios none -kernel build/RunableKernl.elf`.

To clean build artifacts:
```bash
make clean
```
