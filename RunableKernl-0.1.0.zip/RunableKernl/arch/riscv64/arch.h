#ifndef ARCH_H
#define ARCH_H

void arch_init(void);
void arch_halt(void);
void arch_putchar(char c);

#endif // ARCH_H
