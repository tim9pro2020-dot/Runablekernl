#include "uart.h"
#include <stdint.h>

// Standard 16550A UART address for QEMU virt machine
#define UART_BASE 0x10000000

#define UART_THR (volatile uint8_t*)(UART_BASE + 0x00) // Transmitter Holding Buffer
#define UART_LSR (volatile uint8_t*)(UART_BASE + 0x05) // Line Status Register

void uart_init(void) {
    // Minimal init for QEMU - it's mostly pre-initialized by the emulator
}

void uart_putc(char c) {
    // Wait for Transmit Holding Empty (bit 5)
    while ((*UART_LSR & 0x20) == 0);
    *UART_THR = c;
}
