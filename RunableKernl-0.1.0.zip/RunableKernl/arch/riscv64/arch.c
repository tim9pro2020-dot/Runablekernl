#include "arch.h"
#include "uart.h"

void arch_init(void) {
    uart_init();
}

void arch_halt(void) {
    while (1) {
        asm volatile("wfi");
    }
}

void arch_putchar(char c) {
    uart_putc(c);
}
